/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4;

/**
 *
 * @author ranem
 */
    public class SinglyLinkedList<E> {

    static class Node<E> {

        private E element;
        private Node<E> next;

        public Node(E e, Node<E> n) {
            element = e;
            next = n;
        }

        public E getElement() {
            return element;
        }

        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> n) {
            next = n;
        }

        public void setelement(E element) {
            this.element = element;
        }
    }

    Node<E> head;
    Node<E> tail;
    private int size;

    public SinglyLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public E first() {
        if (isEmpty()) {
            return null;
        }
        return head.getElement();
    }

    public E last() {
        if (isEmpty()) {
            return null;
        }
        return tail.getElement();
    }

    public void addFirst(E e) {
        Node<E> newest = new Node<E>(e, null);
        newest.setNext(head);
        head = newest;
        if (size == 0) {
            tail = head;
        }
        size++;
    }

    public void addLast(E e) {
        Node<E> newest = new Node<E>(e, null);
        if (isEmpty()) {
            head = newest;
        } else {
            tail.setNext(newest);
        }
        tail = newest;
        size++;
    }

    public E removeFirst() {
        if (isEmpty()) {
            return null;
        }
        E answer = head.getElement();
        head = head.getNext();
        size--;
        if (size == 0) {
            tail = null;
        }
        return answer;
    }

    public E removeLast() {

        if (size == 0) {
            return null;
        } else {
            E data = tail.getElement();
            if (size == 1) {
                head = tail = null;
            } else {
                Node temp1 = head;
                Node temp2 = null;
                while (temp1.getNext() != null) {
                    temp2 = temp1;
                    temp1 = temp1.getNext();
                }
                temp2.setNext(null);
                tail = temp2;
            }
            size--;
            return data;
        }
    }

    public void printList() {
        Node<E> current = head;
        System.out.println("The head");
        while (current != null) {
            System.out.println(current.getElement());
            current = current.getNext();
        }
        System.out.println("The tail");
    }

    public Product searchID(int ID) {
        Node<E> current = head;
        while (current != null) {
            Product product = (Product) current.getElement();
            if (product.getID() == ID) {
                return product;
            }
            current = current.getNext();
        }
        return null;
    }

    public SinglyLinkedList<Product> uniqueProducts() {
        Node<E> current = head;
        SinglyLinkedList<Product> list = new SinglyLinkedList<>();

        while (current != null) {

            Product ele = (Product) current.getElement();
            Node<E> current2 = head;

            int count = 0;
            while (current2 != null) {
                Product ele2 = (Product) current2.getElement();

                if (ele2.getID() == ele.getID()) {
                    count++;
                }
                current2 = current2.getNext();
            }

            if (count == 1) {
                list.addLast(ele);
            }

            current = current.getNext();
        }

        System.out.println();
        return list;
    }

}

