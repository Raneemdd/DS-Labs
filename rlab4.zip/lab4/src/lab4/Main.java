/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab4;

/**
 *
 * @author ranem
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        SinglyLinkedList<Product> list = new SinglyLinkedList<>();

        Product p1 = new Product(1, "flower");

        Product p2 = new Product(2, "Chicken");
        Product p3 = new Product(4, "Fish");
        Product p4 = new Product(2, "Chicken");
        Product p5 = new Product(3, "Rice");

        Product p6 = new Product(1, "flower");

        list.addLast(p1);
        list.addLast(p2);
        list.addLast(p3);
        list.addLast(p4);
        list.addLast(p5);
        list.addLast(p6);
        System.out.println("Product List:");
        list.printList();

        int searchID = 2;
        System.out.println("Enter product ID to search: " + searchID);
        Product foundProduct = list.searchID(searchID);
        if (foundProduct != null) {
            System.out.println(foundProduct);
            System.out.println("");
        } else {
            System.out.println("Product not found.");
        }
   
        System.out.print("The Non-duplicate products list:");
        SinglyLinkedList<Product> uniqueProductList = list.uniqueProducts();
        uniqueProductList.printList();
    }
    
    }
    

