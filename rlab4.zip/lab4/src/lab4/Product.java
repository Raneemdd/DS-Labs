/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab4;

/**
 *
 * @author ranem
 */
public class Product {
    private int ID;
    private String name;
    
    public Product(int ID, String name) {
        this.ID = ID;
        this.name = name;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

  
    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

 
    @Override
    public String toString() {
        return "Product{ID=" + ID + ", name=" + name + '}';
    }
           
}
