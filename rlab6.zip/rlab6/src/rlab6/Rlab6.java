/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rlab6;

/**
 *
 * @author ranem
 */
public class Rlab6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     LLstack<Book> stack = new LLstack<>();
     stack.push(new Book(101 , "Avengers" , "Action"));
   stack.push(new Book(102, "Frozen", "Animation"));
        stack.push(new Book(103, "Titanic", "Romance"));

        System.out.println("Book Stack:");
        
        stack.printStack();

        System.out.println("\nThe Books with genre 'Action' is:");
        LLstack<Book> actionBooks = stack.bookWithGenre("Action");
        actionBooks.printStack();
        
        
    }
     
     
    }
    
