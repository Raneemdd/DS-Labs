/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rlab6;

/**
 *
 * @author ranem
 */
public class Book {
    private  int ID;
    private String Title;
    private String Genre;

    public Book(int ID, String Title, String Genre) {
        this.ID = ID;
        this.Title = Title;
        this.Genre = Genre;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String Genre) {
        this.Genre = Genre;
    }

    @Override
    public String toString() {
        return "Book{" + "ID=" + ID + ", Title=" + Title + ", Genre=" + Genre + '}';
    }
    
    
}
