
package rlab6;


    public class LLstack<E> {
   //-------------------------------- Node Class --------------------------------------- 
    static class Node<E> {

        private E element; // reference to the element stored at this node
        private Node<E> next; // reference to the subsequent node in the list

        public Node(E e, Node<E> n) {
            element = e;
            next = n;
        }
        public E getElement() {
            return element;
        }
        public Node<E> getNext() {
            return next;
        }

        public void setNext(Node<E> n) {
            next = n;
        }

        public void setelement(E element) {
            this.element = element;
        }
    }
    //-------------------------------- End Node Class ---------------------------------------
    
    private Node<E> top;   // reference to the head node 
    private int size;   // number of elements in the LLstack 

    public LLstack() {   // constructs an empty LLstack
        top = null;
        size = 0;    }

    public int size() {    return size;    }
    public boolean isEmpty() {        return size == 0;    }

    public E top() {
        if (isEmpty()) {
            return null;
        }
        return top.getElement();
    }

    public void push(E elem) {
        Node<E> v = new Node<E>(elem, top);   // create and link-in a new node 
        top = v;
        size++;
    }

    public E pop() {
        if (isEmpty())   return null;
        E temp = top.getElement();
        top = top.getNext();   // link-out the former top node 
        size--;
        return temp;
    }
    
    // printStack
    public void printStack() {
        LLstack<E> temp = new LLstack<E>();

        while (!isEmpty()) {
            E ele = pop();
            System.out.println(ele);
            temp.push(ele);
        }

        while (!temp.isEmpty()) {
            push(temp.pop());
        }
    }

    //  bookWithGenre
    public LLstack<Book> bookWithGenre(String genre) {
        LLstack<Book> result = new LLstack<>();
        LLstack<E> temp = new LLstack<>();

        while (!isEmpty()) {
            E ele = pop();
            temp.push(ele);
            Book book = (Book) ele;
            if (book.getGenre().equals(genre)) {
                result.push(book);
            }
        }

        while (!temp.isEmpty()) {
            push(temp.pop());
        }

        return result;
    }
    
}


