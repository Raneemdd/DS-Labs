/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package raneemdlab1;

import java.util.Scanner;

/**
 *
 * @author ranem
 */
public class Raneemdlab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[][] foodStorage = {
            {"Apple", "Fruit", "50"},
            {"Rice", "Grain", "200"},
            {"Milk", "Dairy", "30"},
            {"Bread", "Bakery", "25"},
            {"Carrot", "Vegetable", "60"}
        };

        displayAllItems(foodStorage);

        String searchName = "Milk";

        searchItem(foodStorage, searchName);
        System.out.println("");
        findLowestQuantity(foodStorage);

    }

    public static void displayAllItems(String[][] foodStorage) {

        System.out.println("All Food Items:");

        System.out.printf("%-15s %-15s %-10s%n", "Name", "Category", "Quantity");
        System.out.println("----------------------------------------");

        for (int i = 0; i < foodStorage.length; i++) {

            for (int j = 0; j < foodStorage[i].length; j++) {
                System.out.printf("%-15s ",
                        foodStorage[i][j]);

            }
            System.out.println("");

        }

    }

    public static void searchItem(String[][] foodStorage, String searchName) {

        boolean found = false;

        for (int i = 0; i < foodStorage.length; i++) {
            if (foodStorage[i][0].equalsIgnoreCase(searchName)) {
                found = true;
                System.out.println("\nFood item found: ");
                System.out.printf("%-15s %-15s %-10s%n", "Name", "Category", "Quantity");
                for (int j = 0; j < foodStorage[i].length; j++) {
                    System.out.printf("%-15s ",
                            foodStorage[i][j]);

                }
                System.out.println("");
                break;
            }
        }

        if (!found) {
            System.out.println("Food item '" + searchName + "' not found .");
        }
    }

    public static void findLowestQuantity(String[][] foodStorage) {

        System.out.println("Food items with Quantity 29 or below:");
        System.out.printf("%-15s %-15s %-10s%n", "Name", "Category", "Quantity");
        System.out.println("----------------------------------------");

        boolean found = false;

        for (int i = 0; i < foodStorage.length; i++) {
            int quantity = Integer.parseInt(foodStorage[i][2]);
            if (quantity <= 29) {
                for (int j = 0; j < foodStorage[i].length; j++) {
                    System.out.printf("%-15s ", foodStorage[i][j]);
                }
                System.out.println("");
                found = true;
            }
        }

        if (!found) {
            System.out.println("No items found with quantity 25 or below.");
            
            
        }
        
    }

}


   
  
