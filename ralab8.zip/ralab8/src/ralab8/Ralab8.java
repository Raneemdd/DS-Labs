
package ralab8;


public class Ralab8 {

   
    public static void main(String[] args) {
        File f1 = new File("project1", 8764215, 2020);
        File f2 = new File("Assiments", 7765439, 2021);
        File f3 = new File("labs", 875319, 2022);
        File f4 = new File("slides", 764258, 2023);
        File f5 = new File("Papers", 764958, 2024);

        BinaryTree<File> files = new BinaryTree<>();

        files.addRoot(f1);
        files.addRight(f5, f1);
        files.addLeft(f4, f1);
        files.addRight(f3, f4);
        files.addLeft(f2, f4);

        System.out.println("Displaying the MyFiles tree:");
        System.out.println("");

        files.Display();
        System.out.println("");

        System.out.println("Is MyFile a proper tree? " + files.isProper());
        System.out.println("");

        System.out.println("Decendents files of sildes :");
        int level = files.DecedentsLevel(f4);
        System.out.println("Level: " + level);
        System.out.println("");

        System.out.println("Files with number 875319");

        File f = files.searchFile(875319);
        System.out.println("{ name:" + f.getName() + " ,Serialnumber: " + f.getSerialNumber() + ", Year:" + f.getReleaseYear() + " }");
        System.out.println("");

        System.out.println("Files in year 2024:");
        files.FileInYear(2024);
        System.out.println("");
        System.out.println("Number of Internal: \n" + files.countInternal());
        System.out.println("");
        files.removeLeaves(f4);
        System.out.println("Tree after removing slides decedent:");
        files.DisplayPost();
    }
}
    
    

