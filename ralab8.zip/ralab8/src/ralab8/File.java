

package ralab8;
public class File {

    private String name;
    private int serialNumber;
    private int releaseYear;

    public File(String name, int serialNumber, int releaseYear) {
        this.name = name;
        this.serialNumber = serialNumber;
        this.releaseYear = releaseYear;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(int serialNumber) {
        this.serialNumber = serialNumber;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    @Override
    public String toString() {
        return "{ name:'" + name + "', Serialnumber:" + serialNumber + ", Year:" + releaseYear + " }";
    }
}