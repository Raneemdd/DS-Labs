
package ralab8;

public class BinaryTree<E> {

    public TreeNode<E> Root;
    public int size;

    public BinaryTree() {
        Root = null;
        size = 0;
    }

    public boolean hasLeft(TreeNode<E> node) {
        return (node.left != null);
    }

    public boolean hasRight(TreeNode<E> node) {
        return (node.right != null);

    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public TreeNode<E> addRoot(E e) {
        if (!isEmpty()) {
            System.out.println("Invalid action: Tree is not empty");
        } else {
            Root = new TreeNode<E>(e);
            size = 1;
        }
        return Root;
    }

    public TreeNode<E> search(TreeNode<E> root, E e, TreeNode<E> result) {
        if (root == null) {
            return null;
        }
        if (e == root.element) {
            return root;
        } else {
            if (root.left != null) {
                result = search(root.left, e, result);
            }

            if (root.right != null) {
                result = search(root.right, e, result);
            }

            return result;
        }

    }

    public void addLeft(E e, E p) {
        TreeNode<E> n = search(Root, p, null);
        if (n != null) {
            if (n.left != null) {
                System.out.println("parent already has a left child");
            } else {
                TreeNode<E> child = new TreeNode(e);
                n.left = child;
                child.parent = n;
                size++;
            }
        } else {
            System.out.println("parent does not exist");
        }
    }

    public void addRight(E e, E p) {
        TreeNode<E> n = search(Root, p, null);
        if (n != null) {
            if (n.right != null) {
                System.out.println("parent already has a left child");
            } else {
                TreeNode<E> child = new TreeNode(e);
                n.right = child;
                child.parent = n;
                size++;
            }
        } else {
            System.out.println("parent does not exist");
        }
    }

    private void Display(TreeNode<E> node) {

        if (node != null) {

            Display(node.left);           // traverse left subtree
            System.out.println(node.element + " ");  // print the node
            Display(node.right);          // traverse right subtree

        }
    }

    private void DisplayPost(TreeNode<E> node) {

        if (node != null) {
            System.out.println(node.element + " ");  // print the node
            Display(node.left);           // traverse left subtree

            Display(node.right);          // traverse right subtree

        }
    }

    public void DisplayPost() {
        DisplayPost(Root);
    }

    public void Display() {
        Display(Root);
    }

    public boolean isProper() {
        return isProper(Root);
    }

    private boolean isProper(TreeNode<E> node) {

        if (node == null) {
            return false;
        }

        if ((node.left == null && node.right == null)) {
            return true;
        }
        if (node.left == null && node.right != null) {
            return false;
        }

        boolean leftIsproper = isProper(node.left);
        boolean rightIsproper = isProper(node.right);

        return leftIsproper && rightIsproper;
    }

    public int DecedentsLevel(TreeNode<E> current, E ele, int level) {
        if (current == null) {
            return -1;
        }

        if (current.element == ele) {

            if (current.left != null) {
                System.out.println(current.left.element);

            }
            if (current.right != null) {
                System.out.println(current.right.element);

            }
            return level;
        }

        int leftResult = DecedentsLevel(current.left, ele, level + 1);
        if (leftResult != -1) {
            return leftResult;
        }

        return DecedentsLevel(current.right, ele, level + 1);
    }

    public int DecedentsLevel(E e) {

        return DecedentsLevel(Root, e, 0);
    }

    public File searchFile(TreeNode<E> node, int number) {
        if (node == null) {
            return null;
        }

        File found = searchFile(node.left, number);
        if (found != null) {
            return found;
        }

        if (((File) node.element).getSerialNumber() == number) {
            return (File) node.element;
        }

        return searchFile(node.right, number);
    }

    public File searchFile(int number) {
        return searchFile(Root, number);
    }

    public void FileInYear(TreeNode<E> root, int year) {
        if (root != null) {
            FileInYear(root.left, year);
            if (((File) root.element).getReleaseYear() == year) {
                System.out.println(root.element);
            }
            FileInYear(root.right, year);

        }
    }

    public void FileInYear(int year) {
        FileInYear(Root, year);
    }

    private int countInternal(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }

        int count = 0;

        if (node.left != null || node.right != null) {
            count++;
        }

        count += countInternal(node.left);
        count += countInternal(node.right);

        return count;
    }

    public int countInternal() {
        return countInternal(Root);
    }

    public void removeLeaves(E e) {
        TreeNode<E> node = search(Root, e, null);
        if (node == null) {//if not found
            System.out.println("Node with element " + e + " not found.");
        } else {//found, remove left and right children connections
            node.left = null;
            node.right = null;
        }
    }

}