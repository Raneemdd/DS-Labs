/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package raneemlab2;

/**
 *
 * @author ranem
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        Flight f1 = new Flight("Riyadh", "Jeddah", 1011);
        Flight f2 = new Flight("Riyadh", "Ad Dammam", 1022);
        Flight f3 = new Flight("Riyadh", "Tabuk", 1033);
        Flight f4 = new Flight("Riyadh", "Medina", 1044);
        Flight f5 = new Flight("Riyadh", "Abha", 1055);

        
        Flight[] flights = new Flight[5];

        
        flights[0] = f1;
        flights[1] = f2;
        flights[2] = f3;
        flights[3] = f4;
        flights[4] = f5;
        

        int FlightID = 1022;
        
        int result = FlightSearch(flights, FlightID);
        

        if (result != -1) {
            
            System.out.println("Flight ID found at index: " + result);
            
        } else {
            
            System.out.println("Sorry, Flight not found.");
        }
        
        System.out.println("");
        
        f5.setToDestination("Oman");

        for (int i = 0; i < flights.length; i++) {
            
            flights[i].DisplayFlights();

        }

    }

    public static int FlightSearch(Flight[] flights, int FlightID) {

        int start = 0;
        
        int end = flights.length - 1;

        while (start <= end) {
            
            int mid = (start + end) / 2;

            if (FlightID == flights[mid].getFlightID()) {
                
                return mid;
                
            } else if (FlightID < flights[mid].getFlightID()) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }

        return -1;
           }
    
    } 

   

