/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package raneemlab2;

/**
 *
 * @author ranem
 */
public class Flight {
    private String from;
    private String toDestination;
    private int flightID;

    public Flight(String from, String toDestination, int flightID) {
        this.from = from;
        this.toDestination = toDestination;
        this.flightID = flightID;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getToDestination() {
        return toDestination;
    }

    public void setToDestination(String toDestination) {
        this.toDestination = toDestination;
    }

    public int getFlightID() {
        return flightID;
    }

    public void setFlightID(int flightID) {
        this.flightID = flightID;
    }
    
    
   public void DisplayFlights() {
        System.out.println("Flight { " + "from = " + from + " ,  ToDestination = " + toDestination + " ,  FlightID = " + flightID + '}');
    }
          
}
