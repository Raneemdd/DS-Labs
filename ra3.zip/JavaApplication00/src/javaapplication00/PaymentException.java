/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication00;

/**
 *
 * @author ranem
 */
public class PaymentException extends Exception {
    
  public PaymentException(String message) {
        super(message);
    }
}
