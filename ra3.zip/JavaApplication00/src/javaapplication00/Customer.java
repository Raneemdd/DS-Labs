/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication00;
import java.util.ArrayList;
/**
 *
 * @author ranem
 */
public class Customer extends AbstractUser implements Payable {
 private double balance;
    private String cart;  

    public Customer(int id, String name, double balance) {
        super(id, name);
        this.balance = balance;
        this.cart = "";
    }

    @Override
    public String getRole() {
        return "Customer";
    }

    public void addToCart(String product) {
        cart = product;
        System.out.println(product + " added to cart.");
    }

    public String getCart() {
        return cart;
    }

    @Override
    public boolean pay(double amount) throws PaymentException {

        if (cart.isEmpty()) {
            throw new PaymentException("Cart is empty!");
        }

        if (balance < amount) {
            throw new PaymentException("Not enough balance!");
        }

        balance -= amount;
        System.out.println("Payment successful. Remaining: " + balance);
        cart = ""; 
        return true;
    }
    
}  

