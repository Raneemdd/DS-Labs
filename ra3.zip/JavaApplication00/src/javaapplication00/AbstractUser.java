/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication00;

/**
 *
 * @author ranem
 */
public abstract class AbstractUser {
    protected int id;
    protected String name;

    public AbstractUser(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public abstract String getRole();

    @Override
    public String toString() {
        return "AbstractUser{" + "id=" + id + ", name=" + name + '}';
    }
    
    
}
   

