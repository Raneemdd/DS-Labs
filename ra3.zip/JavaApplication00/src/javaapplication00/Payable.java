/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package javaapplication00;

/**
 *
 * @author ranem
 */
public interface Payable {
    
     boolean pay(double amount) throws PaymentException;
   
}
